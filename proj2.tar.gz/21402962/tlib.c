#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <malloc.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#include "tlib.h"

readyQ ready;
TCB_node *toTerminate;

void printerror(char * errMsg){
  printf("[!] ERROR-> %s: %s\n",errMsg,strerror(errno));
}

void cleanup_memory(){
  if(toTerminate != NULL){
    free((toTerminate->uc->uc_stack.ss_sp-TLIB_MIN_STACK));
    free(toTerminate->uc);
    free(toTerminate);
    toTerminate = NULL;
  }
}

int insert_TCB_from_uc(ucontext_t* new_context){
  //SETTING UP THE PARAMETERS FOR THE NEW NODE
  TCB_node * new_node = malloc(sizeof(TCB_node));
  if(new_node==NULL){
    printerror("While allocating memory for Thread Control Block");
    return TLIB_NOMEMORY;
  }
  new_node->uc = new_context;
  new_node->next = NULL;
  new_node->id = ready.nextId;

  //UPDATING THE PARAMETERS FOR THE READY QUEUE
  ready.nextId += 1;
  ready.numThreads += 1;

  if(ready.head == NULL){
    ready.head = new_node;
    ready.running = new_node;
  }
  else{
    TCB_node* tmp = ready.head;
    ready.head = new_node;
    new_node->next = tmp;
  }
  return new_node->id;
}

int tlib_init (void){
  toTerminate = NULL;
  ready.numThreads = 0;
  ready.nextId = 1;
  int i = 0;
  ucontext_t * thisContext = (ucontext_t*)malloc(sizeof(ucontext_t));
  if(thisContext==NULL){
    printerror("With allocating memory for the execution context");
    return TLIB_NOMEMORY;
  }
  if(getcontext(thisContext)==-1){
    printerror("Failed getting execution context");
    return TLIB_FAILED;
  }
  if(i == 1){return TLIB_SUCCESS;}
  if(insert_TCB_from_uc(thisContext)==TLIB_ERROR){return TLIB_ERROR;}
  i++;
  return TLIB_SUCCESS;
}

/* implementation of stub is already given below */
void stub (void (*tstartf)(void *), void *arg) {
  	tstartf (arg); /* calling thread start function to execute */
      /*
          We are done with executing the application specified thread start
          function. Hence we can now terminate the thread
      */
  	tlib_delete_thread(TLIB_SELF);
    exit(0);
}

int tlib_create_thread(void (*func)(void *), void *param) {
    //deallocate anything that was scheduled
    cleanup_memory();
    if(ready.numThreads > TLIB_MAX_THREADS){
      printf("[!] WARNING-> Thread limit reached (%d threads) thread not created!\n"
        ,TLIB_MAX_THREADS);
      return TLIB_NOMORE;
    }
    ucontext_t *toCreate = (ucontext_t*)malloc(sizeof(ucontext_t));
    if(toCreate==NULL){
      printerror("While allocating memory for the new execution context");
      return TLIB_NOMEMORY;
    }
    if(getcontext(toCreate)==-1){
      printerror("While getting execution context");
      return TLIB_FAILED;
    }
    unsigned char *sp = (unsigned char*)malloc(TLIB_MIN_STACK);
    if(sp==NULL){
      printerror("While allocating stack for the new execution context");
      return TLIB_NOMEMORY;
    }
    toCreate->uc_stack.ss_sp = sp+TLIB_MIN_STACK;
    toCreate->uc_stack.ss_size = TLIB_MIN_STACK;
    sp = sp+TLIB_MIN_STACK;
    memcpy(sp,&param,sizeof(void *));
	  memcpy(sp-sizeof(void *),&func,sizeof(void *));
    //Return address is useless since it will be destroyed before return
    //but its needed because the function will get our argument like return
    //so we put 0 as return value so if it fails it will FAIL MISERABLY
    //also looks nice inside the stack
    memset(sp-(2*sizeof(void *)),0,sizeof(void *));
    sp-=(sizeof(void *)*2);

    //change stack pointers
    //toCreate->uc_mcontext.gregs[REG_EDI] = (register_t)param;
    toCreate->uc_mcontext.gregs[REG_ESP] = (register_t)sp;
    toCreate->uc_mcontext.gregs[REG_EIP] = (unsigned long int)&stub;
    //returning the TCB id or the error code
    return insert_TCB_from_uc(toCreate);
}

int tlib_yield(int wantTid) {
  //all threads are finished
  if(ready.head == NULL)
    exit(0);
  //deallocate anything that was scheduled
  cleanup_memory();

  // this local variable is used so that the dual return of getcontext won't
  // really cause an infinite context switching back and forth
  int i = 0, check = 0;
  /************** GETTING THE CONTEXT ****************/
  if(getcontext(ready.running->uc)==-1){
    printerror("While getting execution context");
    return TLIB_FAILED;
  }

  //CASE 1: Thread Yields to itself!
  if((wantTid == ready.running->id)||(wantTid == TLIB_SELF)){
    if(i == 0){
      i++;
      check = setcontext(ready.running->uc);
    }
  }
  //CASE 2: We want to yield to a random thread
  else if(wantTid == TLIB_ANY){
    if(i == 0){
      i++;
      //for fairness we run the threads in a circular manner
      //for efficiency we don't move around the TCBs but the pointer
      TCB_node *to_run = ready.running->next;
      if(to_run == NULL)
        to_run = ready.head;
      ready.running = to_run;
      check = setcontext(ready.running->uc);
    }
  }
  //CASE 3: We have a tid different from our own provided so we look for it
  else{
    if(i == 0){
      i++;
      TCB_node *target = ready.head;
      while(target->id != wantTid){
        target = target->next;
        if(target->next == NULL)
          return TLIB_ERROR;
      }
      ready.running = target;
      check = setcontext(ready.running->uc);
    }
  }
  if(check == -1)
    return TLIB_FAILED;
  return TLIB_SUCCESS;
}

int tlib_delete_thread(int tid) {
    //deallocate anything that was scheduled
    cleanup_memory();

    //IF WE ARE GIVEN THE TLIB_SELF CODE OR OUR ID
    if( tid == TLIB_SELF || tid == ready.running->id ) {
      TCB_node * tmp = ready.head,*toDelete = ready.head;
      if(tmp == ready.running){
        ready.head = tmp->next;
        toDelete = tmp;
        tmp = ready.head;
      }
      else{
        while( tmp->next != ready.running ){
          tmp = tmp->next;
          if(tmp == NULL)
            return TLIB_ERROR;
        }
        toDelete = tmp->next;
        tmp->next = tmp->next->next;
      }
      ready.numThreads -= 1;
      toTerminate = toDelete;
      if(ready.numThreads == 0)
        exit(0);
      ready.running = tmp;
      setcontext(ready.running->uc);
      //this won't be executed but is put for code aesthetics
      return TLIB_SUCCESS;
    }
    // IF WE ARE GIVEN AN ID
    if(ready.head->id == tid) {
      toTerminate = ready.head;
      ready.head = ready.head->next;
      cleanup_memory();
      return TLIB_SUCCESS;
    }
    //if the tid to delete was not head
    TCB_node * tmp = ready.head;
    while(tmp->next->id!=tid){
      tmp = tmp->next;
      if(tmp->next == NULL)
        return  TLIB_ERROR;
    }
    toTerminate = tmp->next;
    tmp->next = tmp->next->next;
    cleanup_memory();
    return TLIB_SUCCESS;
}

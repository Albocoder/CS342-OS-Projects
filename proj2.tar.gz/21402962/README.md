CS342-2
Project #2

Project Implementor:
Erin Avllazagaj 21402962


++++++++++++++++++++++++++++++ ADDED STUFF +++++++++++++++++++++++++++++++++++++
I added <string.h> and <errno.h> for memcpy and error reporting respectively.
Also defined __USE_GNU because it didn't recognise the register names.
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

***************************** SOLUTION EXPLAINED *******************************
My solution is based on two very crucial structs I created.
The TCB_node that keeps the needed information about a thread.
These information are the id and the context. The readyQ structure makes it easy
for me to locate and know what thread is running and to make context switching
BLAZING FAST as it is supposed to be.

Any child thread created by tlib_create_thread runs on stub which then doesn't
exit(0) but deletes itself. Deletion of itself is done in the easiest way
possible. This thread is removed from the ready queue and put in a special
place I called toTerminate.It is pretty self-explanatory. The one placed there
will be destroyed in the next function call to the library.All the functions
destroy any thread in toTerminate if there is any.
********************************************************************************

=============================== MORE EXPLANATIONS ==============================
The testing program makes use of every feature that the library provides and
also is easy to read and understand, including the output. (-8 is success)

It has no memory leaks but valgrind fails to see that if not compiled with
-static --debug flags which makes sense.

To see the errors and warnings just grep \\[!\\]
================================================================================

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/stat.h>

struct treenode{
  char * data;
  struct treenode * left;
  struct treenode * right;
};
struct treenode * treeHead;

void * safe_malloc(unsigned int size){
  void * alloc_mem = malloc(size);
  if (alloc_mem == NULL) {
    perror("[!] FATAL: Memory could not be allocated!");
    exit(-1);
  }
  return alloc_mem;
}

char* strtoupper(char * temp) {
  char * toReturn = (char*)safe_malloc(sizeof(char)*(1+strlen(temp)));
  char * tmpChar = toReturn;
  while (*temp) {
    *tmpChar = toupper((unsigned char) *temp);
    tmpChar++;
    temp++;
  }
  return toReturn;
}

void insertNewNodeToTree(struct treenode * node,char * toEnter){
  char * toCompare = strtoupper(toEnter);
  if(node == NULL){
    //the only chance for node to be NULL is for it to be the root
    treeHead = (struct treenode *)safe_malloc(sizeof(struct treenode));
    treeHead->data = (char * )malloc(strlen(toEnter)*sizeof(char));
    strcpy(treeHead->data,toEnter);
    //treeHead->data = toEnter;
    treeHead->left = NULL;
    treeHead->right = NULL;
  }
  else{
    char * data = strtoupper(node->data);
    int whereToGO = strcmp(data,toCompare);
    free(data);
    if (whereToGO>=0) {
      if(node->left== NULL){
        node->left = (struct treenode *)safe_malloc(sizeof(struct treenode));
        node->left->left = NULL;
        node->left->right = NULL;

        node->left->data = (char * )malloc(strlen(toEnter)*sizeof(char));
        strcpy(node->left->data,toEnter);

        //node->left->data = toEnter;
      }else{insertNewNodeToTree(node->left,toEnter);}
    }
    else{
      if(node->right== NULL){
        node->right = (struct treenode *)safe_malloc(sizeof(struct treenode));
        node->right->left = NULL;
        node->right->right = NULL;

        node->right->data = (char * )malloc(strlen(toEnter)*sizeof(char));
        strcpy(node->right->data,toEnter);

        //node->right->data = toEnter;
      }else{insertNewNodeToTree(node->right,toEnter);}
    }
  }
  free(toCompare);
}

void insertWord (char * toInsert){
  insertNewNodeToTree(treeHead,toInsert);
}

void constructTreeFromFile(char* filename){
  char * lineptr = NULL;
  size_t sz = 0;
  FILE *fp;
  if ((fp = fopen(filename, "r")) ==NULL){
    perror("[!] ERROR: In opening the file");
    exit(-1);
  }
  int len = getline(&lineptr,&sz,fp);
  while(len != -1){
    if(lineptr[len-1]=='\n')
      lineptr[len-1] = '\0';
    insertWord(lineptr);
    len = getline(&lineptr,&sz,fp);
  }
  free(lineptr);
  fclose(fp);
}

//could have been more efficient to open and close file once from the wrapper function writeOrdered(char*)
//but since the point is not performance but syscalls then this is better to demostrate the point 
void writeTreeFrom(struct treenode * start,char * filename){
  if(start->left)
    writeTreeFrom(start->left,filename);
  FILE *fp;
  if ((fp = fopen(filename, "a")) ==NULL){
    perror("[!] ERROR: In writing output");
    exit(-1);
  }
  fprintf(fp,"%s\n",start->data);
  fclose(fp);
  if(start->right)
    writeTreeFrom(start->right,filename);
}
void writeOrdered(char * filename){
  writeTreeFrom(treeHead,filename);
}

int main(int argc, char *argv[]){
  if(argc < 3){
    printf("[!] FATAL ERROR: Mismatching number of parameters. Execute like this: %s <inputfile> <outputfile>\n",argv[0]);
    return -1;
  }
  treeHead = NULL;
  constructTreeFromFile(argv[1]);
  writeOrdered(argv[2]);
  return 0;
}
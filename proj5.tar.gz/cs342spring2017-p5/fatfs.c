#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <stdint.h>				// FOR int32_t etc... types
#include <ctype.h>				// FOR toupper() FUNCTION
#include <linux/msdos_fs.h>		// for directory entry

#define SECTORSIZE 512   //bytes
#define BLOCKSIZE  4096  // bytes - do not change this value
#define	VOLINFO_MODE 1
#define ROOTDIR_MODE 2
#define BLOCKS_MODE 3
#define DIR_ENTRY_SZ 32
#define FAT_ENTRY_SZ 4

#define DATA_SEC_OF_CLUSTER(N) (((N - 2) * BPB_SecPerClus)+FirstDataSector)
#define CALC_FAT_SECTOR(a) ((a/(SECTORSIZE/FAT_ENTRY_SZ))+FirstFatSector)
#define CALC_FAT_OFFSET(a) (a%(SECTORSIZE/FAT_ENTRY_SZ))


//useful globals 
char diskname[48]; 
int  disk_fd; 
// obtained by a vanilla boot sector read done in gather_data() function 
uint32_t BPB_RootClus, BS_VolID, TotSec, FatSz, RootDirSectors, FirstDataSector, TotalDataSec,FirstFatSector;
uint16_t BPB_BytsPerSec, BPB_RsvdSecCnt,BPB_RootEntCnt; 
uint8_t BPB_SecPerClus,BPB_NumFATs;
unsigned char BS_VolLab[11]; 


// function prototypes
void opendisk(char * name);
int get_sector (unsigned char *buf, int snum);
void print_sector (unsigned char *s);
int get_execution_method(int argc,char* argv[]);
void gather_data();
void * ec_malloc(int size);
void print_volume_info();
void print_root_directory();
void print_file_blocks(char * fname);
char * get_dir_entry_name(char * name);
char * get_dir_entry_ext(char * name);
char * get_input_fname(char * input);
char * get_input_ext(char * input);
void print_block_recursively(int start_block);

int main(int argc, char *argv[])
{
	int mode = get_execution_method(argc,argv);
	opendisk(argv[1]);
	gather_data();
	
	if (mode == VOLINFO_MODE)
		print_volume_info();
	else if(mode == ROOTDIR_MODE)
		print_root_directory();
	else{
		if(strlen(argv[4]) > MSDOS_NAME){
			printf("[!] ERROR: File name cannot be longer than %d characters\n", MSDOS_NAME);
			exit(1);
		}
		print_file_blocks(argv[4]);
	}

	close (disk_fd); 
	return (0); 
}

int get_execution_method(int argc,char* argv[]){
	if (argc < 2){
		printf("[!] ERROR: Usage %s <volume_name> <parameters>\n", argv[0]);
		exit(1);
	}
	else if (argc < 3){
		opendisk(argv[1]);
		printf("[*] INFO: Opened and closed volume.\n");
		exit(0);
	}
	else if (argc < 4){
		printf("[!] ERROR: Usage %s <volume_name> -p <volumeinfo|rootdir|blocks>\n", argv[0]);
		exit(1);
	}
	else if (argc < 5){
		if(strcmp(argv[2],"-p")!=0){
			printf("[!] ERROR: Unsupported parameter. only -p is allowed for printing");
			exit(1);
		}
		else{
			if(strcmp(argv[3],"volumeinfo")==0)
				return VOLINFO_MODE;
			if(strcmp(argv[3],"rootdir")==0)
				return ROOTDIR_MODE;
			if(strcmp(argv[3],"blocks")==0){
				printf("[!] ERROR: Usage %s <volume_name> -p blocks <filename>\n", argv[0]);
				exit(1);
			}
			else{
				printf("[!] ERROR: Unknown print paramenter. Choose volumeinfo, rootdir or blocks.\n");
				exit(1);
			}
		}
	}
	else{
		if(strcmp(argv[2],"-p")!=0){
			printf("[!] ERROR: Unsupported parameter. only -p is allowed for printing");
			exit(1);
		}
		else{
			if(strcmp(argv[3],"volumeinfo")==0)
				return VOLINFO_MODE;
			if(strcmp(argv[3],"rootdir")==0)
				return ROOTDIR_MODE;
			if(strcmp(argv[3],"blocks")==0)
				return BLOCKS_MODE;
			else{
				printf("[!] ERROR: Unknown print paramenter. Choose volumeinfo, rootdir or blocks.\n");
				exit(1);
			}
		}
	}
}

void print_volume_info(){
	printf("\nDisk name: %s\n", diskname);
	printf("Volume ID:    0x%x\n",BS_VolID);
	printf("Volume Label: %s\n",BS_VolLab);

	printf("\nRead values:\n");
	printf("Location of Root cluster\t=\t%d\n", BPB_RootClus);
	printf("Number of bytes per section\t=\t%d Bytes\n", BPB_BytsPerSec);
	printf("Number of reserved sections\t=\t%d\n", BPB_RsvdSecCnt);
	printf("Number of root entries\t\t=\t%d\n", BPB_RootEntCnt);
	printf("Number of Sectors per Cluster\t=\t%d\n", BPB_SecPerClus);
	printf("Number of FAT tables\t\t=\t%d\n", BPB_NumFATs);

	printf("\nCalculated values:\n");
	printf("Total number of sectors\t\t=\t%d\n", TotSec);
	printf("Total number of data sectors\t=\t%d\n", TotalDataSec);
	printf("First Data Sector\t\t=\t%d\n", FirstDataSector);
	printf("First FAT Sector\t\t=\t%d\n", FirstFatSector);
	printf("Total volume size\t\t=\t%d KBytes\n", TotSec*BPB_BytsPerSec/1024);
	printf("Size of a FAT table\t\t=\t%d KBytes\n", FatSz*BPB_BytsPerSec/1024);
}

void print_root_directory(){
	struct msdos_dir_entry * entry = (struct msdos_dir_entry *)ec_malloc(sizeof(struct msdos_dir_entry));
	unsigned char * buffer = (unsigned char *) ec_malloc(sizeof(unsigned char) * SECTORSIZE);
	get_sector(buffer,DATA_SEC_OF_CLUSTER(BPB_RootClus));
	// Assuming that all the data are in this sector and the entry has name of 11 characters at max

	int i = 0;
	memcpy(entry,buffer,DIR_ENTRY_SZ);
	while( entry->name[1]!=0 ){
		if(IS_FREE(entry->name) || entry->size == -1){
			i++;memcpy(entry,&buffer[i*32],DIR_ENTRY_SZ);continue;
		}
		printf("%s       %s\n",get_dir_entry_name(entry->name)
			,get_dir_entry_ext(entry->name)/*,entry->start,entry->size*/);
		i++;
		memcpy(entry,&buffer[i*32],DIR_ENTRY_SZ);
	}
	free(entry);
	free(buffer);
}

void print_file_blocks(char * fname){
	struct msdos_dir_entry * entry = (struct msdos_dir_entry *)ec_malloc(sizeof(struct msdos_dir_entry));
	unsigned char * buffer = (unsigned char *) ec_malloc(sizeof(unsigned char) * SECTORSIZE);
	get_sector(buffer,DATA_SEC_OF_CLUSTER(BPB_RootClus));
	// Assuming that all the data are in this sector and the entry has name of 11 characters at max

	int i = 0;
	int start_block = -1;
	int size = -1;

	memcpy(entry,buffer,DIR_ENTRY_SZ);
	char * name = get_input_fname(fname);
	char * ext = get_input_ext(fname);

	while( entry->name[1]!=0 ){
		if(IS_FREE(entry->name) || entry->size == -1){
			i++;memcpy(entry,&buffer[i*32],DIR_ENTRY_SZ);continue;
		}
		if( !strcmp(get_dir_entry_name(entry->name),name) && !strcmp(get_dir_entry_ext(entry->name),ext) ){
			start_block = entry->start;
			size = entry->size;
			break;
		}
		i++;
		memcpy(entry,&buffer[i*32],DIR_ENTRY_SZ);
	}
	if(start_block == -1){
		printf("[!] ERROR: File not found!\n");
		exit(4);
	}
	if (size == 0){
		return;
	}
	printf("%s       %s\n",name,ext);
	print_block_recursively(start_block);

	// free(name);
	// free(ext);
	free(entry);
	free(buffer);
}

void print_block_recursively(int start_block){
	if(start_block == FAT_ENT_EOF){
		return;
	}
	else{
		printf("%d : %x\n",start_block,start_block);
		struct msdos_dir_entry * entry = (struct msdos_dir_entry *)ec_malloc(sizeof(struct msdos_dir_entry));
		unsigned char * buffer = (unsigned char *) ec_malloc(sizeof(unsigned char) * SECTORSIZE);
		get_sector(buffer,CALC_FAT_SECTOR(start_block));
		int next_block = 0;
		memcpy(&next_block,&buffer[FAT_ENTRY_SZ*CALC_FAT_OFFSET(start_block)],FAT_ENTRY_SZ);
		free(buffer);
		print_block_recursively(next_block);
	}
}

void opendisk(char * name){
	strcpy (diskname, name); 
    disk_fd = open (diskname, O_RDWR); 
	if (disk_fd < 0) {
		printf ("[!] ERROR: Could not open the disk image\n"); 
		exit (1); 
	}
}

char * get_input_fname(char * input){
	char * toReturn = (char *)ec_malloc(sizeof(char)*MSDOS_NAME);
	memcpy(toReturn,input,MSDOS_NAME);
	
	for (int i = 0; i < MSDOS_NAME; ++i){
		toReturn[i] = toupper(toReturn[i]);
		if(toReturn[i] == '.'){
			toReturn[i] = 0;
			break;
		}
	}
	
	return toReturn;
}

char * get_input_ext(char * input){
	char * toReturn = (char *)ec_malloc(sizeof(char)*MSDOS_NAME);
	memcpy(toReturn,input,MSDOS_NAME);
	int start = MSDOS_NAME-1;
	
	for (int i = 0; i < MSDOS_NAME; ++i){
		if(toReturn[i] == '.'){
			start = i+1;
			break;
		}
	}
	for (int i = start; i < MSDOS_NAME; ++i){
		toReturn[i] = toupper(toReturn[i]);
		if(toReturn[i]==0x20)
			toReturn[i] = 0;
	}
	return &toReturn[start];
}

char * get_dir_entry_name(char * name){
	char * toReturn = (char *)ec_malloc(sizeof(char)*MSDOS_NAME);
	memcpy(toReturn,name,MSDOS_NAME);
	for (int i = 0; i < MSDOS_NAME; ++i){
		if(toReturn[i] == 0x20){
			toReturn[i] = 0;
			break;
		}
	}
	return toReturn;
}

char * get_dir_entry_ext(char * name){
	char * toReturn = (char *)ec_malloc(sizeof(char)*MSDOS_NAME);
	memcpy(toReturn,name,MSDOS_NAME);
	for (int i = 0; i < MSDOS_NAME; ++i){
		if(toReturn[i] == 0x20)
			toReturn[i] = 0;
	}
	int there = 0;
	int start = MSDOS_NAME-1;
	for (int i = 0; i < MSDOS_NAME; ++i){
		if(!there && toReturn[i] == 0)
			there = 1;
		if(there && toReturn[i] != 0){
			start = i;
			break;
		}
	}
	return &toReturn[start];
}

void gather_data(){
	uint16_t BPB_FATSz16,BPB_TotSec16, signature;
	uint32_t BPB_FATSz32,BPB_TotSec32;

	unsigned char * buffer = (unsigned char *) ec_malloc(sizeof(unsigned char) * SECTORSIZE);
	get_sector(buffer,0);

	memcpy(&signature,&buffer[510],2);
	if(signature != 0xAA55){
		printf("[!] ERROR: Volume is corrupted!\n");
		exit(2);
	}

	memcpy(&BS_VolLab,&buffer[71],11);

	memcpy(&BPB_TotSec32,&buffer[32],4);
	memcpy(&BPB_FATSz32,&buffer[36],4);
	memcpy(&BPB_RootClus,&buffer[44],4);
	memcpy(&BS_VolID,&buffer[67],4);

	memcpy(&BPB_BytsPerSec,&buffer[11],2);
	memcpy(&BPB_RsvdSecCnt,&buffer[14],2);
	memcpy(&BPB_RootEntCnt,&buffer[17],2);
	memcpy(&BPB_TotSec16,&buffer[19],2); 
	memcpy(&BPB_FATSz16,&buffer[22],2);

	memcpy(&BPB_SecPerClus,&buffer[13],1);
	memcpy(&BPB_NumFATs,&buffer[16],1);

	
	if(BPB_FATSz16 != 0)
		FatSz = BPB_FATSz16;
	else
		FatSz = BPB_FATSz32;

	if (BPB_TotSec16 != 0)
		TotSec = BPB_TotSec16;
	else
		TotSec = BPB_TotSec32;

	RootDirSectors = ((BPB_RootEntCnt * DIR_ENTRY_SZ) + (BPB_BytsPerSec - 1)) / BPB_BytsPerSec;

	FirstDataSector = BPB_RsvdSecCnt + (BPB_NumFATs * FatSz) + RootDirSectors;

	TotalDataSec = TotSec - (BPB_RsvdSecCnt + (BPB_NumFATs * FatSz) + RootDirSectors);

	FirstFatSector = BPB_RsvdSecCnt+RootDirSectors;

	free(buffer);
}

void * ec_malloc(int size){
	void * mem = malloc(size);
	if(mem == NULL){
		printf("[!] ERROR: Could not allocate memory!\n");
		exit(3);
	}
	return mem;
}


///////////////////// GIVEN FUNCTIONS ////////////////////////
int get_sector (unsigned char *buf, int snum)
{
	off_t offset; 
	int n; 
	offset = snum * SECTORSIZE; 
	lseek (disk_fd, offset, SEEK_SET); 
	n  = read (disk_fd, buf, SECTORSIZE); 
	if (n == SECTORSIZE) 
		return (0); 
	else {
		printf ("sector number %d invalid or read error.\n", snum); 
		exit (1); 
	}
}


void print_sector (unsigned char *s)
{
	int i;

	for (i = 0; i < SECTORSIZE; ++i) {
		printf ("%02x ", (unsigned char) s[i]); 
		if ((i+1) % 16 == 0)
			printf ("\n"); 
	}
	printf ("\n");
}
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/moduleparam.h>
#include <linux/types.h>
#include <linux/fdtable.h>

int pid = 0;
module_param(pid,int,S_IRUSR | S_IWUSR);

// try to do the recursive version of this too
void show_stats(int pid){
  //P1 variables
  // a struct to show the task we are currently monitoring and its' children
  struct task_struct* curr_mon;
  struct list_head* children_list;
  struct task_struct* child_task;
  struct task_struct* target_task = NULL;
  //P2 variables
  struct vm_area_struct* mmap_target;
  unsigned long int total_vm = 0;
  //P3 variables
  struct files_struct* target_files;
  struct file** target_openfds;
  struct file* target_currfile;
  atomic_t index;

  // the following process will acquire the reading lock to be able to read
  rcu_read_lock();

  //  PART 1
  // This was actually a macro defined by the sched.h to traverse the task list
  for_each_process(curr_mon){
    task_lock(curr_mon);
    printk( KERN_INFO "The process\' (name,PID) is (%s,%d)",curr_mon->comm,curr_mon->pid);
    children_list = &curr_mon->children;
    printk( KERN_INFO "Found your parent\'s (name,pid): (%s,%d)"
      ,curr_mon->real_parent->comm,curr_mon->real_parent->pid);
    list_for_each(children_list, &curr_mon->children) {
      child_task = list_entry(children_list,struct task_struct,sibling);
      printk( KERN_INFO "Found your child\'s (name,pid): (%s,%d)"
        ,child_task->comm,child_task->pid);
    }
    if(pid == curr_mon->pid)
      target_task = curr_mon;
    task_unlock(curr_mon);
  }

  //  PART 2
  if(target_task == NULL){
    printk(KERN_ALERT "PID not found!");
    return;
  }
  if(target_task->mm == NULL){
    printk(KERN_ALERT "This process has no corresponding virtual memory!");
    return;
  }
  mmap_target = target_task->mm->mmap;
  while( mmap_target!=NULL){
    total_vm += mmap_target->vm_end-mmap_target->vm_start;
    printk( KERN_INFO "Found your information for pid(%d) (start,end,size): (0x%lx,0x%lx,%ld)"
      ,target_task->pid,mmap_target->vm_start,mmap_target->vm_end
      ,mmap_target->vm_end-mmap_target->vm_start);
    mmap_target = mmap_target->vm_next;
  }
  printk( KERN_INFO "Total size of the virtual memory for pid(%d) is: %ld Bytes"
    ,target_task->pid,total_vm);

  //  PART 3
  atomic_set(&index,0);
  target_files = target_task->files;
  target_openfds = target_files->fd_array;
  while(atomic_read(&index) < atomic_read(&target_files->count)){
    target_currfile = target_openfds[atomic_read(&index)];
    atomic_inc(&index);
    if(target_currfile->f_path.dentry == NULL)
      continue;
    if(target_currfile->f_path.dentry->d_iname[0] != '\0'){
      printk( KERN_INFO "Opened file\'s name is %s and its size is %lld Bytes. UID IS %u"
        ,target_currfile->f_path.dentry->d_iname,i_size_read(target_currfile->f_inode),
        target_currfile->f_inode->i_uid);
    }
  }
  rcu_read_unlock();
}

static int mod_init(void){
  show_stats(pid);
  return 0;
}

static void mod_exit(void){
  printk(KERN_ALERT "TEST: Module is now destroyed!\n");
}

module_init(mod_init);
module_exit(mod_exit);

MODULE_DESCRIPTION("This module\'s purpose is to show information about the running processes, like the pid, memory usage, opened files etc.");
MODULE_LICENSE("GPL");

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <math.h>

#ifndef MAX_PHILOSOPHERS
#define MAX_PHILOSOPHERS 27
#endif

//data type definition
typedef enum distribution{uniform,exponential} distribution;
typedef enum status{eating,thinking,hungry,done} status;
typedef struct stats{
  status st;
  int id;
  int eaten_times;
  long * hungry_time;
} stats;

/*********************** function prototypes **********************/
// functions for philosopher and the philosopher thread
void * philosopher(void * stone);
void eat(stats * s);
void * think(int ms,stats * my_stats);
int rand_with_distro(distribution distro,int min,int max);
void acquire_sticks(stats * s);
void release_sticks(stats * s);
// integrity checkers and useful error handlers
void * ec_malloc(size_t size);
void check_numphil(int numphil);
void test_distribution(enum distribution distro);
// measurer function
long get_curr_ms();
// statistical functions
double std_deviation(stats * s);
double avg_hunger(stats * s);
double total_hungry_ms(stats * s);
/******************** function prototypes end ********************/

//global variables
int numphil,minthink,maxthink,mineat,maxeat,count;
enum distribution dist;
pthread_mutex_t * mon_mutex;
int * sticks;
pthread_cond_t * sticks_cond;
stats * all_stats;

int main(int argc, char *argv[]) {
  // Taking up the request for the dinner from the sponsor(king of philosophers)
  if(argc < 8){
    printf("[!] ERROR -> Usage: %s <numphil> <minthink> <maxthink> <mineat> <maxeat> <dist> <count>\n", argv[0]);
    exit(1);
  }
  mon_mutex = (pthread_mutex_t*)ec_malloc(sizeof(pthread_mutex_t));
  if(pthread_mutex_init(mon_mutex,NULL)!=0){
    printf("[!] ERROR -> Mutex initialization error!");
    exit(2);
  }
  numphil = atoi(argv[1]);
  //if its just one make it look like 3
  if(numphil == 1)
    numphil = 3;
  //checking if numer of philosophers is consistent with the assignment
  check_numphil(numphil);

  minthink = atoi(argv[2]);
  maxthink = atoi(argv[3]);
  mineat = atoi(argv[4]);
  maxeat = atoi(argv[5]);
  dist = (strcmp("uniform",argv[6])==0)?uniform:exponential;
  count = atoi(argv[7]);
  srand(time(0));

  // Setting up the stage and placing food.
  sticks = (int*)ec_malloc(sizeof(int)*numphil);
  sticks_cond = (pthread_cond_t *) ec_malloc(sizeof(pthread_cond_t)*numphil);
  pthread_t* philosophers = (pthread_t *)malloc(sizeof(pthread_t)*numphil);
  all_stats = (stats*)malloc(sizeof(stats)*numphil);

  // Placing sticks in the table
  for (int i = 0; i < numphil; i++){
    sticks[i] = 1;
    all_stats[i].st = thinking;
    all_stats[i].id = i;
    all_stats[i].eaten_times = 0;
    all_stats[i].hungry_time = (long *)malloc(sizeof(long)*count);
    for (int j = 0; j < count; j++)
      all_stats[i].hungry_time[j] = 0L;
    // initialize condition
    pthread_cond_init(&sticks_cond[i],NULL);
  }

  // Escorting the philosophers to their seats
  // if its just one
  if( atoi(argv[1]) == 1 ){
    pthread_create(&philosophers[0],NULL,philosopher,&all_stats[0]);
    pthread_join(philosophers[0],NULL);
    printf("philosopher %d duration of hungry state = %ld\n",1
      ,(long)total_hungry_ms(&all_stats[0]));
    exit(0);
  }
  //else
  for (int i = 0; i < numphil; i++)
    pthread_create(&philosophers[i],NULL,philosopher,&all_stats[i]);

  // Waiting for them to fill up their stomachs and minds
  for (int i = 0; i < numphil; i++)
    pthread_join(philosophers[i],NULL);

  for (int i = 0; i < numphil; i++)
    printf("philosopher %d duration of hungry state = %ld\n",i+1
      ,(long)total_hungry_ms(&all_stats[i]));

  // display results
  for(int i = 0; i < numphil; i++)
    printf("[.] INFO: Average hunger time and Standard deviation for philosopher %d: { %f , %f }\n",
      i,avg_hunger(&all_stats[i]),std_deviation(&all_stats[i]));

  // Cleaning up
  pthread_mutex_destroy(mon_mutex);
  for (int i = 0; i < numphil; i++)
    pthread_cond_destroy(&sticks_cond[i]);
  free(sticks);
  free(sticks_cond);
  free(all_stats);
  return 0;
}

// a philosopher and his stone(aka id and status)
void * philosopher(void * stone){
  while( ((stats*)stone)->eaten_times < count ){
    ((stats*)stone)->st = hungry;
    eat((stats*)stone);
    printf("philosopher %d thinking\n",((stats*)stone)->id+1);
    think(rand_with_distro(dist,minthink,maxthink),(stats*)stone);
  }
  ((stats*)stone)->st = done;
  pthread_exit(0);
  return NULL;
}
void * think(int ms,stats * my_stats){
  struct timespec specat;
  my_stats->st = thinking;
  specat.tv_nsec = (ms % 1000) * 1000000;
  specat.tv_sec = ms / 1000;
  nanosleep(&specat,&specat);
  return NULL;
}
void eat(stats * s){
  s->st = hungry;
  long start = get_curr_ms();
  printf("philosopher %d hungry\n",s->id+1);
  acquire_sticks(s);
  long difference = get_curr_ms()-start;
  difference = difference>0?difference:-difference;
  s->hungry_time[s->eaten_times] = difference;

  //eat the food (uses thinging timeout)
  printf("philosopher %d eating\n",s->id+1);
  think(rand_with_distro(dist,mineat,maxeat),(stats*)s);
  s->eaten_times++;

  if(s->eaten_times >= count)
    s->st = done;
  //release resources
  // printf("philosopher %d releases\n",s->id+1);
  release_sticks(s);
}

// random number generator
int rand_with_distro(distribution distro,int min,int max){
  double myRand = rand()/(1.0 + RAND_MAX);
  if(distro == uniform) {
    int range = max - min + 1;
    int myRand_scaled = (myRand * range) + min;
    return myRand_scaled;
  }
  else {
    double mean = (double)(min+max)/2.0;
    double rand_double = (double)rand() / (double)RAND_MAX; //random in interval (0,1)
    int generated = (int)(-log(rand_double)*(mean));
    while(generated < min || generated > max){
      rand_double = (double)rand()/(double)RAND_MAX;
      generated = (int)(-log(rand_double)*(mean));
    }
    return generated;
  }
}

//function that safely acquires the sticks and must be called when lock acquired
void acquire_sticks(stats * s){
  pthread_mutex_lock(mon_mutex);
  if(s->id%2==0){
    while(sticks[s->id] == 0)
      pthread_cond_wait(&sticks_cond[s->id],mon_mutex);
    sticks[s->id] = 0;
    while(sticks[(s->id+numphil-1)%numphil] == 0)
      pthread_cond_wait(&sticks_cond[(s->id+numphil-1)%numphil],mon_mutex);
    sticks[(s->id+numphil-1)%numphil] = 0;
  }
  else{
    while(sticks[(s->id+numphil-1)%numphil] == 0)
      pthread_cond_wait(&sticks_cond[(s->id+numphil-1)%numphil],mon_mutex);
    sticks[(s->id+numphil-1)%numphil] = 0;
    while(sticks[s->id] == 0)
      pthread_cond_wait(&sticks_cond[s->id],mon_mutex);
    sticks[s->id] = 0;
  }
  s->st = eating;
  pthread_mutex_unlock(mon_mutex);
}

//releases the sticks
void release_sticks(stats * s){
  pthread_mutex_lock(mon_mutex);
  sticks[s->id] = 1;
  pthread_cond_signal(&sticks_cond[s->id]);
  sticks[(s->id+numphil-1)%numphil] = 1;
  pthread_cond_signal(&sticks_cond[(s->id+numphil-1)%numphil]);
  pthread_mutex_unlock(mon_mutex);
}

//*************************** Common functions *******************************//
//error checked malloc
void * ec_malloc(size_t size){
  void * mem = malloc(size);
  if (mem == NULL){
    printf("[!] ERROR -> While allocating memory!\n");
    exit(5);
  }
  return mem;
}

// test code checking if correct distribution
void test_distribution(enum distribution distro){
  int * count = (int*)ec_malloc(1000*sizeof(int));
  for(int i = 0; i < 1000; i++)
    count[i] = 0;
  for(int i = 0; i < 10000; i++)
    count[rand_with_distro(distro,0,1000)-1]++;
  for (int i = 0; i < 1000; i++)
    printf("%d -> %d\n",i+1,count[i]);
}

// checks for integrity in the number of philosophers
void check_numphil(int numphil){
  if(numphil > MAX_PHILOSOPHERS){
    printf("[!] ERROR -> Max number of philosophers exceeded.(Max = %d)\n", MAX_PHILOSOPHERS);
    exit(3);
  }
  if(numphil%2 == 0){
    printf("[!] ERROR -> Number of philosophers must be odd.\n");
    exit(4);
  }
}

// get the ms of epoch at that time
long get_curr_ms(){
  struct timespec specs;
  clock_gettime(CLOCK_REALTIME, &specs);
  return lround(specs.tv_nsec / 1.0e6);
}

// find standard deviation of a philosophers hungry time
double std_deviation(stats * s){
  double total_deviaton = 0;
  double avg_hungry_time = avg_hunger(s);

  for (int i = 0; i < count; i++)
    total_deviaton += pow(((double)s->hungry_time[i]-avg_hungry_time),2.0);

  return pow((total_deviaton/(double)count),0.5);
}

// find the average of a philosophers hungry time
double avg_hunger(stats * s){
  return (double)total_hungry_ms(s)/(double)count;
}

double total_hungry_ms(stats * s){
  long total = 0;
  for(int i = 0; i < count; i++)
    total += s->hungry_time[i];
  return total;
}
//*********************** End of Common functions ****************************//

#include "commons.h"
#include <pthread.h>

typedef struct thread_args{
	llnode ** head;
	char * filename;
	char * keyword;
}thread_args;


void * runner(void * arg) {
	thread_args* args = (thread_args*)arg;
	llnode * head = (llnode *)args->head;
	char * input = args->filename;
	char * keyword = args->keyword;

	FILE * fs = NULL;
	fs = fopen(input,"r");
	if (fs == NULL)
		err_handle("[!!] FATAL - The input file couldn't be opened");

	//// SETTING UP THE PARAMETERS FOR READING ////
	char * outputdata = (char*) efmalloc(400*sizeof(char));
	*outputdata = '\0';
	char * line = NULL;
	size_t len = 0;
	int read = getline(&line, &len, fs);
	int currentline = 1;
	////	END OF READINGS SETUP ////

	while (read >= 0) {
		if(findall(line,keyword) == 1) {
			strcat(outputdata,input);
			char * linedata = (char *)efmalloc(20*sizeof(char));
			snprintf(linedata, 20,", %d: ", currentline);
			strcat(outputdata,linedata);
			strcat(outputdata,line);
			//insert the line into the linked list
			insert_to_ll(&head,outputdata);
			free(linedata);
			*outputdata = '\0';
		}
		read = getline(&line, &len, fs);
		currentline++;
	}
	free(outputdata);
	fclose(fs);
	pthread_exit(0);
}

int main(int argc, char *argv[]){
	int numargs = atoi(argv[2]);
	CHECK_ARGS_VALIDITY

	//preparing threads' data
	pthread_t tids[numargs];
	pthread_attr_t attrs[numargs];

	//creating linked list heads for all the threads
	llnode ** heads = (llnode**)efmalloc(sizeof(llnode*)*numargs);
	for(int i = 0; i < numargs; i+=sizeof(llnode*))
		heads[i] = NULL;

	//initializing attributes of threads
	for (int index = 0; index < numargs; index++)
		pthread_attr_init(&attrs[index]);

	//ordering arguments
	char * files[numargs];
	for (int index = 0; index < numargs; index++)
		files[index] = argv[3+index];
	qsort(files,numargs,sizeof(char*),cstring_cmp);

	//compiling arg for the threads
	thread_args ** args = (thread_args**)efmalloc(sizeof(thread_args*)*numargs);
	for (int index = 0; index < numargs; index+=1){
		args[index] = (thread_args*)efmalloc(sizeof(thread_args));
		args[index]->filename = files[index];
		args[index]->head = &heads[index];
		args[index]->keyword = argv[1];
	}

	//running the threads
	for(int i = 0; i < numargs;i++)
		pthread_create(&tids[i],&attrs[i],runner,args[i]);

	//wait for all the threads to be done
	for(int i = 0; i < numargs;i++)
		pthread_join(tids[i],NULL);

	//write the linked list data in the specified file
	FILE * fd = fopen(argv[3+numargs],"w");
	for(int i = 0; i < numargs;i++)
		dumpll(heads[i],fd);

	//no need to free cuz it will be freed anyway
	return 0;
}

#include "commons.h"
//this header is included to call the right function wait::wait(NULL)
#include <sys/wait.h>

//checks if all the pipes are closed and thus finished writing
int arefinished(unsigned int toCheck[],int size){
	for(int i = 0;i < size; i++){
		if(toCheck[i]!=0)
			return 1;
	}
	return 0;
}

//gets the dump from the pipe and tries to organize it into linked lists
char * getstringsfrompipe(char * unread,char * data,int size,llnode ** listhead){
	char * pointA = data;
	char * pointB = data+strlen(data);
	if(unread != NULL){
		char * toAdd = (char*)efmalloc((strlen(unread)+1+strlen(pointA))*sizeof(char));
		*toAdd = '\0';
		strcpy(toAdd,unread);
		strcat(toAdd,pointA);
		//printf("Adding the concatenated string: %s\n", toAdd);
		insert_to_ll(listhead,toAdd);
		free(toAdd);
		toAdd = NULL;
		pointA = pointB+1;
		pointB = pointA+strlen(pointA);
	}
	if(size < BUFFER_SIZE){
		while(pointB<data+size){
			insert_to_ll(listhead,pointA);
			pointA = pointB+1;
			pointB = pointA+strlen(pointA);
		}
		free(unread);
		return NULL;
	}
	else{
		while(pointB<data+BUFFER_SIZE){
			insert_to_ll(listhead,pointA);
			pointA = pointB+1;
			pointB = pointA+strlen(pointA);
		}
		char * toReturn = (char*)efmalloc((strlen(pointA)+1)*sizeof(char));
		strcpy(toReturn,pointA);
		free(unread);
		return toReturn;
	}
}

int main(int argc, char *argv[]){
	int numargs = atoi(argv[2]);
	CHECK_ARGS_VALIDITY
	pid_t n;
	int fds[numargs][2];

	for (int i = 0; i < numargs; i++) {
		if(pipe(fds[i])==-1)
			err_handle("[!!] FATAL: Couldn\'t create a pipe!");
	}
	char * files[numargs];
	for (int index = 0; index < numargs; index++)
		files[index] = argv[3+index];
	qsort(files,numargs,sizeof(char*),cstring_cmp);

	for(int i = 0; i < numargs;i++){
		n = fork();
		if(n < 0)
			err_handle("[!!] FATAL: Couldn\'t create a child process ");
		else if(n==0){
			close(fds[i][0]);//closing the read end of the pipe for the children
			FILE * fs = NULL;
			fs = fopen(files[i],"r");
			if (fs == NULL)
				err_handle("[!!] FATAL: The file Couldn't be opened!");

			//// SETTING UP THE PARAMETERS FOR READING ////
			char * outputdata = (char*) efmalloc(400*sizeof(char));
			*outputdata = '\0';
			char * line = NULL;
			size_t len = 0;
			int read = getline(&line, &len, fs);
			int currentline = 1;
			////	END OF READINGS SETUP ////

			while (read >= 0) {
				if(findall(line,argv[1]) == 1) {
					strcat(outputdata,files[i]);
					char * linedata = (char *)efmalloc(20*sizeof(char));
					snprintf(linedata, 20,", %d: ", currentline);
					strcat(outputdata,linedata);
	        strcat(outputdata,line);
					//Write the data in the pipe in here
					write(fds[i][1],outputdata,(strlen(outputdata)+1));
					free(linedata);
					*outputdata = '\0';
				}
				read = getline(&line, &len, fs);
				currentline++;
    	}
			free(outputdata);
			fclose(fs);
			close(fds[i][1]);	//now closing the write end of the pipe
			exit(0);
		}
	}
	if( n!=0 ) {
		//creating linked lists for each file
		llnode ** heads = (llnode**)efmalloc(sizeof(llnode*)*numargs);
		for(int i = 0; i < numargs; i++)
			heads[i] = NULL;
		//message buffer
		char * readmsg = (char*)efmalloc(BUFFER_SIZE*sizeof(char));
		//a stored half-string for each file while processing
		char * unread[numargs];
		//integer to keep the status of the pipe of each file
		for(int i = 0; i < numargs; i++)
			unread[i] = NULL;
		FILE * fd = fopen(argv[3+numargs],"w");
		if(fd == NULL)
			err_handle("[!!] FATAL: Couldn\'t create a file!");
		unsigned int stats[numargs];
		//close the write end for all the pipess
		for (int index = 0; index < numargs; index++)
			close(fds[index][1]);
		do{
			for(int j = 0; j < numargs; j++){
				stats[j] = read(fds[j][0],readmsg,BUFFER_SIZE);
				unread[j] = getstringsfrompipe(unread[j],readmsg,stats[j],&heads[j]);
			}
		}
		while(arefinished(stats,numargs));

		//kill all the children processes and dump each linked list
		//in the output file
		for(int i = 0; i < numargs;i++){
    	wait(NULL);
			dumpll(heads[i],fd);
		}
		fclose(fd);
	}
	//no need to free cuz it will be freed anyway
	return 0;
}

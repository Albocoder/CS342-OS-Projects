#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

//macro used to check arguments' validity
#ifndef CHECK_ARGS_VALIDITY
#define BUFFER_SIZE 100
#define ARGS_ERROR_MSG "[!!] FATAL: Bad number of args. Format: %s <keyword> <N(>=1)> < N inputfiles...> <outputfile>\n"
#define ERROR_EXIT printf(ARGS_ERROR_MSG,argv[0]);exit(-1);
#define CHECK_ARGS_VALIDITY if(argc<5){ERROR_EXIT}if(argc!=3+atoi(argv[2])+1){ERROR_EXIT}
#endif


//error handler that prints out errors in a neat and tidy way
//although errors aren't neat xD
void err_handle(const char * msg){
	perror(msg);
	exit(-1);
}

//error free malloc is a function that check for error after malloc-ing
void * efmalloc(unsigned int size){
	void * allocated_memory = malloc(size);
	if(allocated_memory == NULL)
		err_handle("[!!] FATAL: Couldn\'t allocate memory!\n");
	return allocated_memory;
}

//a failsafe and true-positive searcher of a keyword in a line
//only for the first occurrence
char * findword(char * line,char * keyword){
	char * start = NULL;
	start = strstr(line,keyword);
	if( start != NULL){
		if(start == line){
			if(*(start+strlen(keyword))=='\t'||*(start+strlen(keyword))==' '||*(start+strlen(keyword))=='\n')
				return start;
			else
				return start+1;
		}
		else{
			if((*(start+strlen(keyword))=='\t'
					||*(start+strlen(keyword))==' '
					||*(start+strlen(keyword))=='\n')&&
					((*(start-1)=='\t')||(*(start-1)==' ')))
				return start;
			else
				return start+1;
		}
	}
	else
		return 0;
}

//this is the WRAPPER function of the failsafe single find above
//this guy here will try to find the one we'r looking for even if
//it fails at first attempt
//this is the complete form of search for keyword
int findall(char * line,char * keyword){
	char * start = 0;
	start = findword(line,keyword);
	while(start != 0){
		if(*start!=*keyword)
			start = findword(start,keyword);
		else
			return 1;
	}
	return 0;
}

//comparison function for strings that must be passed to the qsort function
int cstring_cmp(const void * a, const void * b){
	const char ** aa = (const char **)a;
	const char ** bb = (const char **)b;
	return strcmp(*aa,*bb);
}

//this function will create a unique intermediate file name for each child
//the parent then will use this to read the file and delete it afterwards
char * getIntermediateFileName(char * source){
	char * outputfilename = (char *)efmalloc(((strlen(source)+38)
						*sizeof(char)));
	strcpy(outputfilename,source);
	strcat(outputfilename,"-childfindingsoutputfile.intermediate");
	return outputfilename;
}

//this copies lines from the intermediate file to the output
void from_intermediate_to_output(FILE * myIntermediateFile,FILE * outputFile){
	char * line = NULL;
	size_t len = 0;
	int read = getline(&line, &len, myIntermediateFile);
	while (read >=0) {
		fwrite(line,sizeof(char),strlen(line),outputFile);
		read = getline(&line, &len, myIntermediateFile);
	}
	fclose(myIntermediateFile);
}

typedef struct llnode{
	struct llnode * next;
	char * data;
}llnode;

void insert_to_ll(llnode ** start, char * toInsert){
	if(*start == NULL){
		*start = (llnode *)efmalloc(sizeof(llnode));
		(*start)->next = NULL;
		(*start)->data = (char *) efmalloc((strlen(toInsert)+1)*sizeof(char));
		strcpy((*start)->data,toInsert);
		return;
	}
	llnode* tmp = (*start);
	while(tmp->next!=NULL)
		tmp = tmp->next;
	tmp->next = (llnode *) efmalloc(sizeof(llnode));
	tmp->next->next = NULL;
	tmp->next->data = (char *) efmalloc((strlen(toInsert)+1)*sizeof(char));
	strcpy(tmp->next->data,toInsert);
}

//this prints out the nodes of a linked list from a starting point
//usually it's called with starting point as head of the list
void printll(llnode * start){
	printf("[ ");
	while (start != NULL) {
		printf("%s ", start->data);
		start = start->next;
	}
	printf("]\n");
}

//this function is used to dump a linked list in a file
void dumpll(llnode * start,FILE * myfile){
	while (start != NULL) {
		fwrite(start->data,sizeof(char),strlen(start->data),myfile);
		start = start->next;
	}
}

#include "commons.h"
//this header is included to call the right function wait::wait(NULL)
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int numargs = atoi(argv[2]);
	pid_t n;
	//checking for the right number of arguments defined in the macro
	CHECK_ARGS_VALIDITY

	for(int i = 0; i < numargs;i++){
		n = fork();
		if(n < 0)
			err_handle("[!!] FATAL: Couldn\'t create a child process ");
		else if(n==0){
			FILE * fs = NULL;
			fs = fopen(argv[3+i],"r");
			if (fs == NULL)
				err_handle("[!!] FATAL: The file Couldn't be opened!");

			//// SETTING UP THE PARAMETERS FOR READING ////
			char * outputdata = (char*) efmalloc(400*sizeof(char));
			*outputdata = '\0';
			char * line = NULL;
			size_t len = 0;
			int read = getline(&line, &len, fs);
			int currentline = 1;
			//// SETUP INTERMEDIATE FILES WRITING ////
			char * outputfilename = getIntermediateFileName(argv[3+i]);
			FILE * myIntermediateFile = fopen(outputfilename,"w");
			if(myIntermediateFile == NULL)
				err_handle("[!!] FATAL: Opening file for output!\n");
			while (read >= 0) {
				//printf("Processing  line:%s\n", line);
				if(findall(line,argv[1]) == 1) {
					strcat(outputdata,argv[3+i]);
					char * linedata = (char *)efmalloc(20*sizeof(char));
					snprintf(linedata, 20,", %d: ", currentline);
					strcat(outputdata,linedata);
	        strcat(outputdata,line);
					strcat(outputdata,"\0");
					fwrite(outputdata,sizeof(char),strlen(outputdata),myIntermediateFile);
					free(linedata);
					*outputdata = '\0';
				}
				read = getline(&line, &len, fs);
				currentline++;
    	}
			free(outputdata);
			free(outputfilename);
			fclose(myIntermediateFile);
			fclose(fs);
			exit(0);
		}
	}
	if(n!=0) {
		for(int i = 0; i < numargs;i++)
    	wait(NULL);
		//SORTING THE FILENAMES USING qsort
		char * files[numargs];
		for (int index = 0; index < numargs; index++)
			files[index] = argv[3+index];
		qsort(files,numargs,sizeof(char*),cstring_cmp);
		//OPENING OUTPUT FILE FOR WRITING
		FILE * outputFile = fopen(argv[3+numargs],"w");
		for(int i = 0; i < numargs;i++){
			//GET FILES IN ORDERED MANNER
			char * filename = getIntermediateFileName(files[i]);
			FILE * myIntermediateFile = fopen(filename,"r");
			if(myIntermediateFile==NULL){
				printf("[!] Error: File \"%s\" not found! Continuing...\n", filename);
				free(filename);continue;
			}
			from_intermediate_to_output(myIntermediateFile,outputFile);
			remove(filename);
			free(filename);
		}
		fclose(outputFile);
	}
	return 0;
}

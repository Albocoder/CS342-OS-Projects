# cs342-fall2016-p1
Project 1


Name: Erin Avllazagaj
ID: 21402962 

<br>
I added the sys/wait.h header to avoid implicit calls and undefined behaviour. 
<br>
I used macros to check for right number of arguments.
<br>
Since some functions and parst of the procedure are the same for all the programs I added them into the commons.h and incluede the latter in all the programs.
